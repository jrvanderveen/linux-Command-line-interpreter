/* result.h
    getresult():     returns evaluation of calculation or error 
    returnResult:    returns result after getresult determines first and seccond num, oporator, pass check, and error to getresult 
*/


int getresult (char *line);

int returnResult(int firstN, int seccondN, char oporator, short error, short pass);
