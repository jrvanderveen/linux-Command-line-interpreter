/* pipe.h


*/

// gettokens returns an array of strings

